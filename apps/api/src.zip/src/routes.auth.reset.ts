// apps/api/src/routes.auth.reset.ts
import type { Request, Response } from 'express';
import crypto from 'node:crypto';
import argon2 from 'argon2';
import { parseEnv } from '@habitrack/core-config';
import { MariaDbSessionStore } from '@habitrack/session-store';
import { q } from './db';
import { logAudit } from './audit';

const cfg = parseEnv(process.env);

const IS_PROD =
  String(cfg.HABITRACK_ENV || process.env.NODE_ENV || 'development').toLowerCase() === 'production';

const REQUIRE_TLS =
  IS_PROD &&
  String(cfg.HABITRACK_DB_REQUIRE_TLS ?? 'false')
    .trim()
    .toLowerCase() === 'true';

const SESSION_TTL_MIN = Number(cfg.HABITRACK_SESSION_TTL_MINUTES ?? 120) || 120;
const COOKIE_NAME = String(cfg.HABITRACK_SESSION_COOKIE_NAME ?? 'habitrack_sid');
const COOKIE_SAMESITE = String(cfg.HABITRACK_COOKIE_SAMESITE ?? 'Lax')
  .trim()
  .toLowerCase() as 'lax' | 'strict' | 'none';
const COOKIE_SECURE =
  IS_PROD &&
  (String(cfg.HABITRACK_COOKIE_SECURE ?? 'true')
    .trim()
    .toLowerCase() === 'true' ||
    COOKIE_SAMESITE === 'none');

const store = new MariaDbSessionStore({
  host: String(cfg.HABITRACK_DB_HOST ?? '127.0.0.1'),
  port: Number(cfg.HABITRACK_DB_PORT ?? 3306),
  user: String(cfg.HABITRACK_DB_USER ?? 'habitrack_app'),
  password: String(cfg.HABITRACK_DB_PASSWORD ?? ''),
  database: String(cfg.HABITRACK_DB_NAME ?? 'habitrack'),
  connectionLimit: Number(cfg.HABITRACK_DB_POOL_MAX ?? 10),
  requireTls: REQUIRE_TLS,
});

// argon2 settings used elsewhere
const ARGON2_OPTS_BASE: argon2.Options & { raw: true } = {
  type: argon2.argon2id,
  timeCost: 3,
  memoryCost: 64 * 1024,
  parallelism: 1,
  raw: true,
};

function setSessionCookie(res: Response, sid: string) {
  res.cookie(COOKIE_NAME, sid, {
    httpOnly: true,
    secure: COOKIE_SECURE,
    sameSite: COOKIE_SAMESITE,
    path: '/',
    maxAge: SESSION_TTL_MIN * 60_000,
  });
}

function clientMeta(req: Request) {
  return {
    ip:
      (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() ||
      (req.socket?.remoteAddress ?? undefined),
    ua: (req.headers['user-agent'] as string | undefined) ?? undefined,
  };
}

async function getUserRole(userId: number): Promise<'admin' | 'member' | 'kid' | 'kiosk'> {
  const rows = await q<Array<{ roleId: 'admin' | 'member' | 'kid' | 'kiosk' }>>(
    'SELECT roleId FROM users WHERE id = ? LIMIT 1',
    [userId],
  );
  return rows?.[0]?.roleId ?? 'member';
}

function timingSafeEq(a: Buffer, b: Buffer): boolean {
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

// ====== POST /api/auth/creds/forgot ========================================
// Body: { userId: number }
// Dev: returns { devCode: '123456' } so you can test; Prod: returns 204.
// Creates/overwrites a short-lived code (10 minutes).
export async function postForgotPassword(req: Request, res: Response) {
  const { userId } = (req.body ?? {}) as { userId?: number };
  const { ip, ua } = clientMeta(req);

  if (!userId) {
    return res.status(400).json({ error: { code: 'BAD_REQUEST', message: 'userId required' } });
  }

  const user = await q<Array<{ id: number }>>('SELECT id FROM users WHERE id=? LIMIT 1', [userId]);
  if (!user.length) {
    // respond generically; still audit
    await logAudit({
      action: 'auth.forgot',
      result: 'ok',
      actorId: undefined,
      ip,
      ua,
      details: { userId, nonexistent: true },
    });
    return IS_PROD ? res.status(204).end() : res.json({ devCode: '000000' });
  }

  // generate 6-digit numeric code
  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const codeHash = crypto.createHash('sha256').update(code).digest(); // 32 bytes
  const expiresAt = new Date(Date.now() + 10 * 60_000);

  await q(
    `INSERT INTO password_resets (userId, codeHash, expiresAt, attempts, createdAt)
     VALUES (?,?,?,?,NOW(3))
     ON DUPLICATE KEY UPDATE codeHash=VALUES(codeHash), expiresAt=VALUES(expiresAt), attempts=0, createdAt=VALUES(createdAt)`,
    [userId, codeHash, expiresAt],
  );

  await logAudit({ action: 'auth.forgot', result: 'ok', actorId: userId, ip, ua });

  // TODO: send via email/SMS; dev returns code inline
  if (IS_PROD) return res.status(204).end();
  return res.json({ devCode: code });
}

// ====== POST /api/auth/creds/reset =========================================
// Body: { userId: number, code: string, newSecret: string }
// Verifies code, updates credentials, rotates all sessions, issues a fresh cookie session.
export async function postResetPassword(req: Request, res: Response) {
  const { userId, code, newSecret } = (req.body ?? {}) as {
    userId?: number;
    code?: string;
    newSecret?: string;
  };
  const { ip, ua } = clientMeta(req);

  if (!userId || !code || !newSecret) {
    return res
      .status(400)
      .json({ error: { code: 'BAD_REQUEST', message: 'userId, code, newSecret required' } });
  }

  // load reset row
  const rows = await q<Array<{ codeHash: Buffer; expiresAt: Date; attempts: number }>>(
    'SELECT codeHash, expiresAt, attempts FROM password_resets WHERE userId=? LIMIT 1',
    [userId],
  );
  const r = rows?.[0];
  const now = Date.now();

  if (!r || new Date(r.expiresAt).getTime() <= now || r.attempts >= 5) {
    await logAudit({
      action: 'auth.reset',
      result: 'deny',
      actorId: userId,
      ip,
      ua,
      details: { reason: 'expired_or_missing' },
    });
    return res.status(400).json({ error: { code: 'INVALID_RESET' } });
  }

  const givenHash = crypto.createHash('sha256').update(code).digest();
  const okCode = timingSafeEq(givenHash, r.codeHash);

  if (!okCode) {
    await q('UPDATE password_resets SET attempts = attempts + 1 WHERE userId=?', [userId]);
    await logAudit({
      action: 'auth.reset',
      result: 'deny',
      actorId: userId,
      ip,
      ua,
      details: { reason: 'bad_code' },
    });
    return res.status(400).json({ error: { code: 'INVALID_RESET' } });
  }

  // Update password (argon2id)
  if (typeof newSecret !== 'string' || newSecret.length < 8) {
    return res.status(400).json({ error: { code: 'WEAK_PASSWORD', message: 'min 8 chars' } });
  }
  const salt = crypto.randomBytes(16);
  const hash = (await argon2.hash(newSecret, { ...ARGON2_OPTS_BASE, salt })) as Buffer;

  await q(
    `INSERT INTO credentials (userId, provider, algo, salt, hash, updatedAt)
     VALUES (?, 'password', 'argon2id', ?, ?, NOW(3))
     ON DUPLICATE KEY UPDATE algo=VALUES(algo), salt=VALUES(salt), hash=VALUES(hash), updatedAt=VALUES(updatedAt)`,
    [userId, salt, hash],
  );

  // Rotate sessions: delete all sessions for user
  await q('DELETE FROM sessions WHERE user_id=?', [userId]);
  await q('DELETE FROM password_resets WHERE userId=?', [userId]);

  // New session & cookie
  const role = await getUserRole(userId);
  const sess = await store.create({ userId, role, ttlMinutes: SESSION_TTL_MIN });
  setSessionCookie(res, sess.sid);

  await logAudit({ action: 'auth.reset', result: 'ok', actorId: userId, ip, ua });

  return res.status(204).end();
}
