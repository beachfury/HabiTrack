// apps/api/src/notify/index.ts
import { SmtpOutboxProvider } from './smtp-provider';
export const Notifier = SmtpOutboxProvider;
