// apps/api/src/scripts/migrate.js — read secrets from env; fix path; no hardcoded pw
import { execSync } from 'node:child_process';
import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import 'dotenv/config';

const MIGRATIONS_DIR = join(
  process.cwd(),
  '..',
  '..',
  'providers',
  'storage-mariadb',
  'migrations',
);
const files = readdirSync(MIGRATIONS_DIR)
  .filter((f) => /^\d+_.*\.sql$/i.test(f))
  .sort();

const DB = process.env.HABITRACK_DB || process.env.HABITRACK_DB_NAME || 'habitrack';
const ROOT_PASS = process.env.MARIADB_ROOT_PASSWORD || '';
const PASS_ARG = ROOT_PASS ? `-p\"${ROOT_PASS}\"` : '';

for (const f of files) {
  const p = join(MIGRATIONS_DIR, f);
  const sql = readFileSync(p, 'utf8');
  console.log(`[migrate] applying ${f}`);
  execSync(`docker exec -i habitrack-db mariadb -uroot ${PASS_ARG} -D ${DB}`, {
    input: sql,
    stdio: ['pipe', 'inherit', 'inherit'],
    shell: true,
  });
}
console.log('[migrate] done');
