import type { Request, Response } from 'express';
import { parseEnv } from '@habitrack/core-config';
import { makeLocalClassifier } from '@habitrack/net';
import { q } from './db';
import { logAudit } from './audit';

const cfg = parseEnv(process.env);
const BOOTSTRAP_HEADER = String(cfg.HABITRACK_BOOTSTRAP_HEADER ?? 'X-HabiTrack-Kiosk-Token');

function envList(v: unknown): string[] {
  if (Array.isArray(v)) return v as string[];
  if (v == null) return [];
  return String(v)
    .split(',')
    .map((t) => t.trim())
    .filter(Boolean);
}

const classify = makeLocalClassifier({
  trustedProxies: envList(cfg.trustedProxies),
  localCidrs: envList(cfg.localCidrs).length
    ? (cfg.localCidrs as any)
    : ['127.0.0.1/32', '::1/128', '10.0.0.0/8', '192.168.0.0/16'],
});

export async function postBootstrapAdmin(req: Request, res: Response) {
  const info = classify(req);

  // DEV convenience: allow localhost even if proxy classification disagrees
  const isDev = String(process.env.HABITRACK_ENV || '').toLowerCase() === 'development';
  const hostIsLocal =
    req.hostname === 'localhost' ||
    req.hostname === '127.0.0.1' ||
    req.ip === '127.0.0.1' ||
    req.ip === '::1' ||
    req.ip === '::ffff:127.0.0.1';

  if (!info.isLocal && !(isDev && hostIsLocal)) {
    return res.status(403).json({
      error: { code: 'PERMISSION_DENIED', message: 'Local network required' },
    });
  }

  const token = (req.header(BOOTSTRAP_HEADER) || '').trim();
  if (!token) {
    return res.status(401).json({
      error: { code: 'AUTH_REQUIRED', message: `Missing ${BOOTSTRAP_HEADER}` },
    });
  }

  const [row] = await q<Array<{ isBootstrapped: number }>>(
    `SELECT isBootstrapped FROM settings WHERE id=1`,
  );
  if (row?.isBootstrapped) {
    return res.status(409).json({
      error: { code: 'ALREADY_BOOTSTRAPPED', message: 'Already bootstrapped' },
    });
  }

  const result: any = await q(
    `INSERT INTO users (displayName, roleId, kioskOnly, active) VALUES (?,?,0,1)`,
    ['Admin', 'admin'],
  );
  await q(`UPDATE settings SET isBootstrapped = 1, updatedAt = NOW(3) WHERE id = 1`);

  await logAudit({
    action: 'bootstrap.admin',
    result: 'ok',
    ip: info.clientIp ?? undefined,
    ua: (req.headers['user-agent'] as string | undefined) ?? undefined,
    details: { via: 'bootstrap', header: BOOTSTRAP_HEADER },
  });

  return res.status(201).json({
    user: { id: result.insertId as number, displayName: 'Admin', role: 'admin' as const },
  });
}
