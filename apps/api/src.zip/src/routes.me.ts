import type { Request, Response } from 'express';

// req.user is populated by requireAuth()
export async function getMe(req: Request, res: Response) {
  const u = (req as any).user as
    | { id: number; displayName: string; roleId: 'admin' | 'member' | 'kid' | 'kiosk' }
    | undefined;

  if (!u) return res.status(401).json({ error: { code: 'AUTH_REQUIRED' } });
  return res.json({ user: { id: u.id, displayName: u.displayName, role: u.roleId } });
}
