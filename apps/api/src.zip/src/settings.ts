import { parseEnv } from '@habitrack/core-config';
import { q } from './db';

type DynSettings = {
  allowedOrigins: string[];
  trustedProxies: string[];
  localCidrs: string[];
};

const cfg = parseEnv(process.env);
let dyn: DynSettings = {
  allowedOrigins: cfg.allowedOrigins ?? [],
  trustedProxies: cfg.trustedProxies ?? [],
  localCidrs: cfg.localCidrs ?? [],
};

export function getSettings(): DynSettings {
  return dyn;
}

export async function reloadSettings() {
  // table shape (from your migration):
  // settings(id=1, allowedOrigins TEXT, localCidrs TEXT, trustedProxies TEXT, ...)
  const rows = await q<
    Array<{
      allowedOrigins: string | null;
      localCidrs: string | null;
      trustedProxies: string | null;
    }>
  >(`SELECT allowedOrigins, localCidrs, trustedProxies FROM settings WHERE id=1`);

  if (rows.length) {
    const row = rows[0];
    const parseList = (txt: string | null | undefined) =>
      (txt || '')
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);

    dyn = {
      allowedOrigins: row.allowedOrigins
        ? parseList(row.allowedOrigins)
        : (cfg.allowedOrigins ?? []),
      trustedProxies: row.trustedProxies
        ? parseList(row.trustedProxies)
        : (cfg.trustedProxies ?? []),
      localCidrs: row.localCidrs ? parseList(row.localCidrs) : (cfg.localCidrs ?? []),
    };
  }
}
