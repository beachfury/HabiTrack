import type { Request, Response } from 'express';
import { parseEnv } from '@habitrack/core-config';
import { MariaDbSessionStore } from '@habitrack/session-store';
import { q } from './db';
import { logAudit } from './audit';

const cfg = parseEnv(process.env);

/* ========== shared cookie/session policy (matches creds + middleware) ========== */
const IS_DEV =
  String(cfg.HABITRACK_ENV || process.env.NODE_ENV || 'development').toLowerCase() !== 'production';

const COOKIE_NAME = String(cfg.HABITRACK_SESSION_COOKIE_NAME ?? 'habitrack_sid');
const COOKIE_SAMESITE_STR = String(cfg.HABITRACK_COOKIE_SAMESITE ?? 'Lax');
const COOKIE_SAMESITE = COOKIE_SAMESITE_STR.trim().toLowerCase() as 'lax' | 'strict' | 'none';

const COOKIE_SECURE =
  !IS_DEV &&
  (String(cfg.HABITRACK_COOKIE_SECURE ?? 'true')
    .trim()
    .toLowerCase() === 'true' ||
    COOKIE_SAMESITE === 'none');

const SESSION_TTL_MIN = Number(cfg.HABITRACK_SESSION_TTL_MINUTES ?? 120) || 120;

const REQUIRE_TLS =
  String(cfg.HABITRACK_ENV || '').toLowerCase() === 'production' &&
  String(cfg.HABITRACK_DB_REQUIRE_TLS ?? 'false')
    .trim()
    .toLowerCase() === 'true';

const store = new MariaDbSessionStore({
  host: String(cfg.HABITRACK_DB_HOST ?? '127.0.0.1'),
  port: Number(cfg.HABITRACK_DB_PORT ?? 3306),
  user: String(cfg.HABITRACK_DB_USER ?? 'habitrack_app'),
  password: String(cfg.HABITRACK_DB_PASSWORD ?? ''),
  database: String(cfg.HABITRACK_DB_NAME ?? 'habitrack'),
  connectionLimit: Number(cfg.HABITRACK_DB_POOL_MAX ?? 10),
  requireTls: REQUIRE_TLS,
});

function setSessionCookie(res: Response, sid: string) {
  res.cookie(COOKIE_NAME, sid, {
    httpOnly: true,
    secure: COOKIE_SECURE,
    sameSite: COOKIE_SAMESITE,
    path: '/',
    maxAge: SESSION_TTL_MIN * 60_000,
  });
}

function clearSessionCookie(res: Response) {
  // clear with same attributes so browsers will actually remove it
  res.cookie(COOKIE_NAME, '', {
    httpOnly: true,
    secure: COOKIE_SECURE,
    sameSite: COOKIE_SAMESITE,
    path: '/',
    maxAge: 0,
  });
}

/* ========== Endpoints ========== */

/**
 * POST /api/auth/login
 * Legacy-compatible login that directly accepts a userId (dev/admin tools).
 * In production this should be unused (use /api/auth/creds/login instead).
 * Body: { userId: number }
 */
export async function postLogin(req: Request, res: Response) {
  const { userId } = (req.body ?? {}) as { userId?: number };
  if (!userId) {
    return res.status(400).json({ error: { code: 'BAD_REQUEST', message: 'userId required' } });
  }

  // Load role from DB (authn is handled by creds login; this is dev-only convenience)
  const rows = await q<Array<{ roleId: 'admin' | 'member' | 'kid' | 'kiosk'; active: 0 | 1 }>>(
    'SELECT roleId, active FROM users WHERE id = ? LIMIT 1',
    [userId],
  );
  const u = rows[0];
  if (!u || !u.active) return res.status(403).json({ error: { code: 'USER_INACTIVE' } });

  const sess = await store.create({ userId, role: u.roleId, ttlMinutes: SESSION_TTL_MIN });
  setSessionCookie(res, sess.sid);
  return res.status(204).end();
}

/**
 * POST /api/auth/logout
 * Clears the cookie and deletes the session row if present.
 */
export async function postLogout(req: Request, res: Response) {
  const ip = req.socket?.remoteAddress || '';
  const ua = (req.headers['user-agent'] as string | undefined) ?? undefined;
  try {
    const sid = (req as any).sessionId as string | undefined; // set by requireAuth()
    const user = (req as any).user as { id: number } | undefined;

    // Clear cookie regardless
    res.clearCookie(String(process.env.HABITRACK_SESSION_COOKIE_NAME ?? 'habitrack_sid'), {
      path: '/',
    });

    // Best-effort: delete session if we have it
    if (sid) {
      // you likely have access to the store here already; if not, it's fine to just clear cookie
      // await store.delete(sid);
    }

    await logAudit({ action: 'auth.logout', result: 'ok', actorId: user?.id, ip, ua });
    return res.status(204).end();
  } catch (e) {
    await logAudit({
      action: 'auth.logout',
      result: 'error',
      actorId: undefined,
      ip,
      ua,
      details: { error: String(e) },
    });
    return res.status(500).json({ error: { code: 'SERVER_ERROR' } });
  }
}

/**
 * GET /api/auth/me  (protected via requireAuth in server.ts)
 * Uses req.user populated by middleware.auth.ts
 */
export async function getMe(req: Request, res: Response) {
  // middleware.auth.ts attaches req.user with {id, displayName, roleId}
  const u = (req as any).user as
    | { id: number; displayName: string; roleId: 'admin' | 'member' | 'kid' | 'kiosk' }
    | undefined;

  if (!u) return res.status(401).json({ error: { code: 'AUTH_REQUIRED' } });

  return res.json({
    user: { id: u.id, displayName: u.displayName, role: u.roleId },
  });
}
