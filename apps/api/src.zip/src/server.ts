// aaps/api/src/server.ts
import * as dotenv from 'dotenv';
dotenv.config({ path: process.env.NODE_ENV === 'production' ? '.env.production' : '.env' });

import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';

import { parseEnv } from '@habitrack/core-config';
import { makeLocalClassifier } from '@habitrack/net';
import { sessionRequired, requirePerm, HttpError } from '@habitrack/http';
import type { Context, Session } from '@habitrack/http';
import type { RoleId } from '@habitrack/perm';
import { getKioskSummary } from '@habitrack/kiosk';
import { Kiosk } from '@habitrack/http-contracts';

import { postLogin, postLogout } from './routes.auth';
import { getMe } from './routes.me';
import { getSettings, reloadSettings } from './settings';
import { getRoleRules, refreshPermissions } from './permissions';
import { issueCsrf, csrfProtect } from './csrf';
import { countUsersByRole } from './users';
import { q } from './db';
import { getApiKeyAuth } from './apiKeys';
import {
  postRegisterCreds,
  postLoginCreds,
  postChangePassword,
  postForgotPassword,
  postResetPassword,
} from './routes.auth.creds';
import { postBootstrapAdmin } from './routes.bootstrap';

import { requireAuth } from './middleware.auth';
import { MariaDbSessionStore } from '@habitrack/session-store';
import { postAdminCreateUser } from './routes.admin.users';
import { postOnboardComplete } from './routes.auth.onboard';
import { listPermissions, replacePermissions, reloadPermissions } from './routes.permissions';

const cfg = parseEnv(process.env);
const app = express();

/* ===========================
   Dynamic settings + permissions refresh
   =========================== */
reloadSettings().catch(console.error);
refreshPermissions().catch(console.error);
setInterval(() => reloadSettings().catch(() => {}), 5 * 60 * 1000);
setInterval(() => refreshPermissions().catch(() => {}), 5 * 60 * 1000);

/* ===========================
   CORS
   =========================== */
app.use(
  cors({
    origin(origin, cb) {
      const dyn = getSettings();
      const allowList = dyn.allowedOrigins.length
        ? dyn.allowedOrigins
        : cfg.allowedOrigins.length
          ? cfg.allowedOrigins
          : [cfg.HABITRACK_BASE_URL];
      if (!origin) return cb(null, true);
      cb(null, allowList.includes(origin));
    },
    credentials: true,
  }),
);
app.use(express.json());
app.use(cookieParser());

app.get('/api/permissions', requireAuth('admin'), listPermissions);
app.put('/api/permissions', requireAuth('admin'), replacePermissions);
app.post('/api/permissions/refresh', requireAuth('admin'), reloadPermissions);

/* ===== Debug helpers (optional) ===== */
app.get('/api/_debug/csrf', (req, res) => {
  const cookieName = cfg.HABITRACK_CSRF_COOKIE_NAME ?? 'habitrack_csrf';
  res.json({
    cookieName,
    cookieValue: (req as any).cookies?.[cookieName] ?? null,
    headerName: cfg.HABITRACK_CSRF_HEADER_NAME ?? 'X-HabiTrack-CSRF',
    cookieSecure:
      String(process.env.HABITRACK_ENV || process.env.NODE_ENV || 'development').toLowerCase() ===
      'production',
    sameSite: String(cfg.HABITRACK_COOKIE_SAMESITE ?? 'Lax'),
  });
});

/* ===== Auth routes ===== */
app.post('/api/auth/login', postLogin); // dev/legacy login path unified
app.post('/api/auth/logout', postLogout); // unified logout
app.post('/api/auth/creds/register', postRegisterCreds); // real creds
app.post('/api/auth/creds/login', postLoginCreds); // real creds
app.post('/api/bootstrap/admin', postBootstrapAdmin);
app.post('/api/auth/creds/forgot', postForgotPassword);
app.post('/api/auth/onboard/complete', postOnboardComplete);
app.post('/api/admin/users', requireAuth('admin'), postAdminCreateUser);

/* ===== CSRF ===== */
app.get('/api/auth/csrf', issueCsrf);
app.use(csrfProtect);
app.post('/api/auth/creds/reset', postResetPassword);

/* ===== Protected routes ===== */
app.get('/api/me', requireAuth('admin', 'member', 'kid', 'kiosk'), getMe);
app.post('/api/auth/creds/change', requireAuth(), postChangePassword);

function envList(v: unknown): string[] {
  if (Array.isArray(v)) return v as string[];
  if (v == null) return [];
  const s = String(v).trim();
  if (!s || s.toLowerCase() === 'undefined' || s.toLowerCase() === 'null' || s === '[]') return [];
  return s
    .split(',')
    .map((t) => t.trim())
    .filter(Boolean);
}

const trustedProxiesList = envList(cfg.trustedProxies);
const localCidrsList = envList(cfg.localCidrs).length
  ? (cfg.localCidrs as any)
  : ['127.0.0.1/32', '::1/128', '10.0.0.0/8', '192.168.0.0/16'];

const classify = makeLocalClassifier({
  trustedProxies: trustedProxiesList,
  localCidrs: localCidrsList,
});

const classifyWithLoopbackFix = (req: express.Request) => {
  const info = classify(req);
  const peer = req.socket?.remoteAddress || '';
  const isLoopbackPeer = peer === '::1' || peer === '127.0.0.1' || peer === '::ffff:127.0.0.1';
  if (isLoopbackPeer) {
    const xff = (req.headers['x-forwarded-for'] as string | undefined)?.split(',')[0]?.trim();
    if (xff) {
      const local =
        /^(127\.|10\.|192\.168\.)/.test(xff) || xff === '::1' || xff.startsWith('::ffff:127.');
      return { clientIp: xff, source: 'x-forwarded-for' as const, isLocal: local };
    }
    return { clientIp: peer, source: 'socket' as const, isLocal: true };
  }
  return info;
};

const classifyReq =
  (process.env.HABITRACK_ENV || process.env.NODE_ENV) === 'development'
    ? classifyWithLoopbackFix
    : classify;

// dev-only header to spoof a role (handy for tools)
function getDevSessionFromHeader(req: express.Request): Session | null {
  if (cfg.HABITRACK_ENV !== 'development') return null;
  const role = (req.header('x-demo-role') || '').toLowerCase();
  const ok = ['admin', 'member', 'kid', 'kiosk'] as const;
  return (ok as readonly string[]).includes(role) ? ({ userId: 1, role } as Session) : null;
}

/* --- Cookie-backed session loader (no sessionLoader middleware needed) --- */
const IS_DEV =
  String(cfg.HABITRACK_ENV || process.env.NODE_ENV || 'development').toLowerCase() !== 'production';
const COOKIE_NAME = String(cfg.HABITRACK_SESSION_COOKIE_NAME ?? 'habitrack_sid');
const REQUIRE_TLS =
  String(cfg.HABITRACK_ENV || '').toLowerCase() === 'production' &&
  String(cfg.HABITRACK_DB_REQUIRE_TLS ?? 'false')
    .trim()
    .toLowerCase() === 'true';

const sessionStore = new MariaDbSessionStore({
  host: String(cfg.HABITRACK_DB_HOST ?? '127.0.0.1'),
  port: Number(cfg.HABITRACK_DB_PORT ?? 3306),
  user: String(cfg.HABITRACK_DB_USER ?? 'habitrack_app'),
  password: String(cfg.HABITRACK_DB_PASSWORD ?? ''),
  database: String(cfg.HABITRACK_DB_NAME ?? 'habitrack'),
  connectionLimit: Number(cfg.HABITRACK_DB_POOL_MAX ?? 10),
  requireTls: REQUIRE_TLS,
});

// Read cookie -> fetch session row -> return { userId, role } | null
async function getCookieSession(req: express.Request): Promise<Session | null> {
  const sid = (req.cookies?.[COOKIE_NAME] ?? '').trim();
  if (!sid) return null;
  const s = await sessionStore.get(sid).catch(() => null);
  if (!s) return null;
  return { userId: s.userId, role: s.role as any };
}

/* ===========================
   Context builder (API key OR cookie OR dev header)
   =========================== */
function makeContext(req: express.Request): Context {
  const api = getApiKeyAuth(req); // Bearer takes precedence
  const netInfo = classifyReq(req);
  const isLocal = netInfo.isLocal;

  // We return a Context synchronously; cookie session will be resolved per-route if needed
  // by calling sessionRequired(ctx) AFTER we attach a best-effort session below.
  const dev = getDevSessionFromHeader(req);

  // NOTE: we cannot await here; attach a lazy getter or do a quick sync read:
  // For simplicity, do a synchronous snapshot the routes can use immediately:
  (req as any).__ctxCookiePromise ??= getCookieSession(req);

  const cookieSnapshot = (req as any).__ctxCookieSnapshot as Session | null | undefined;
  const session = api
    ? ({ userId: 0, role: api.role } as Session)
    : (cookieSnapshot ?? dev ?? null);

  return {
    session,
    isLocalRequest: isLocal,
    isBootstrapped: true,
    getRoleRules, // from ./permissions
  };
}

// If a route needs strong assurance of cookie session in Context,
// resolve it before calling sessionRequired(ctx):
async function ensureCookieSessionIn(ctx: Context, req: express.Request) {
  if (ctx.session) return;
  const p: Promise<Session | null> | undefined = (req as any).__ctxCookiePromise;
  const s = p ? await p : await getCookieSession(req);
  (req as any).__ctxCookieSnapshot = s;
  (ctx as any).session = s;
}

/* ===========================
   Basic health + debug
   =========================== */
app.get('/api/health', (_req, res) => res.json({ ok: true }));

app.get('/api/_debug/net', (req, res) => {
  const info = classifyReq(req);
  res.json({ trustedProxiesList, localCidrsList, info });
});

app.get('/api/_debug/db', async (_req, res) => {
  try {
    const [row] = await q<Array<{ now: string }>>('SELECT NOW(3) as now');
    res.json({ ok: true, now: row?.now ?? null });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

app.get('/api/_debug/settings', (_req, res) => {
  res.json(getSettings());
});

/* ===========================
   Permission checks (external apps / UI)
   =========================== */

// GET variant for API-key or cookie callers: /api/perm/check?action=foo.bar
app.get('/api/perm/check', async (req, res, next) => {
  try {
    const action = String(req.query.action || '').trim();
    if (!action)
      return res.status(400).json({ error: { code: 'BAD_REQUEST', message: 'action required' } });

    const api = getApiKeyAuth(req);
    if (api?.requireLocal && !classifyReq(req).isLocal) {
      return res.status(403).json({
        error: { code: 'PERMISSION_DENIED', message: 'Local network required for this API key' },
      });
    }

    const ctx = makeContext(req);
    await ensureCookieSessionIn(ctx, req); // 🔸 add this
    sessionRequired(ctx);
    requirePerm(action)(ctx);
    return res.json({ allowed: true });
  } catch (err) {
    next(err);
  }
});

app.post('/api/perm/check', async (req, res, next) => {
  try {
    const api = getApiKeyAuth(req);
    if (api?.requireLocal && !classifyReq(req).isLocal) {
      return res.status(403).json({
        error: { code: 'PERMISSION_DENIED', message: 'Local network required for this API key' },
      });
    }

    const ctx = makeContext(req);
    await ensureCookieSessionIn(ctx, req); // 🔸 add this
    sessionRequired(ctx);

    const { action } = (req.body ?? {}) as { action?: string };
    if (!action)
      return res.status(400).json({ error: { code: 'BAD_REQUEST', message: 'action required' } });

    requirePerm(action)(ctx);
    return res.json({ allowed: true });
  } catch (err) {
    next(err);
  }
});

/* ===========================
   Example: kiosk summary (localOnly via permission)
   =========================== */
app.get('/api/kiosk/summary', async (req, res, next) => {
  try {
    const ctx = makeContext(req);
    await ensureCookieSessionIn(ctx, req);
    sessionRequired(ctx);
    requirePerm('dashboard.read')(ctx);

    const summary = await getKioskSummary({
      countUsersByRole: async (role) => countUsersByRole(role),
      getKioskDisplayName: async () => 'Household',
    });

    const parsed = Kiosk.KioskSummaryResponseSchema.parse(summary);
    res.json(parsed);
  } catch (err) {
    next(err);
  }
});
/* ===========================
   Error handling
   =========================== */
app.use(
  (err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    if (err instanceof HttpError) {
      return res
        .status(err.status)
        .json({ error: { code: err.code, message: err.message, details: err.details } });
    }
    console.error(err);
    return res
      .status(500)
      .json({ error: { code: 'SERVER_ERROR', message: 'Unexpected server error' } });
  },
);

const port = Number(process.env.PORT ?? 3000);
app.listen(port, () => console.log(`HabiTrack API listening on http://localhost:${port}`));
