import crypto from 'crypto';
import type { Request, Response, NextFunction } from 'express';
import { parseEnv } from '@habitrack/core-config';
import { getApiKeyAuth } from './apiKeys';

const cfg = parseEnv(process.env);

// Decide cookie security based on environment
const ENV = String(
  process.env.HABITRACK_ENV || process.env.NODE_ENV || 'development',
).toLowerCase();
// In dev: never secure (HTTP). In prod: always secure.
const COOKIE_SECURE = ENV === 'production';

// Names/attrs
const CSRF_COOKIE = String(cfg.HABITRACK_CSRF_COOKIE_NAME ?? 'habitrack_csrf');
const CSRF_HEADER = String(cfg.HABITRACK_CSRF_HEADER_NAME ?? 'X-HabiTrack-CSRF');
const COOKIE_SAMESITE =
  (String(cfg.HABITRACK_COOKIE_SAMESITE ?? 'Lax').toLowerCase() as 'lax' | 'strict' | 'none') ??
  'lax';

// Optional: one-line startup log to avoid future confusion
if (process.env.NODE_APP_INSTANCE == null) {
  console.log('[csrf-cookie]', {
    env: ENV,
    name: CSRF_COOKIE,
    secure: COOKIE_SECURE,
    sameSite: COOKIE_SAMESITE,
  });
}

export function issueCsrf(req: Request, res: Response) {
  // Reuse existing cookie if valid; otherwise mint new
  let token = (req as any).cookies?.[CSRF_COOKIE];
  if (!token || typeof token !== 'string' || token.length < 32) {
    token = crypto.randomBytes(32).toString('hex');
    res.cookie(CSRF_COOKIE, token, {
      httpOnly: false, // must NOT be httpOnly for double-submit pattern
      secure: COOKIE_SECURE, // dev=false, prod=true
      sameSite: COOKIE_SAMESITE, // Lax by default unless changed
      path: '/',
      maxAge: 2 * 60 * 60 * 1000, // 2h
    });
  }
  res.json({ header: CSRF_HEADER, token });
}

export function csrfProtect(req: Request, res: Response, next: NextFunction) {
  // NEW: Skip CSRF entirely for valid Bearer API keys (service-to-service)
  const api = getApiKeyAuth(req);
  if (api) return next();

  // Allow safe methods
  const m = req.method.toUpperCase();
  if (m === 'GET' || m === 'HEAD' || m === 'OPTIONS') return next();

  const cookieToken = (req as any).cookies?.[CSRF_COOKIE] || '';
  const headerToken = (req.header(CSRF_HEADER) || '').trim();

  if (
    cookieToken &&
    headerToken &&
    cookieToken.length === headerToken.length &&
    crypto.timingSafeEqual(Buffer.from(cookieToken), Buffer.from(headerToken))
  ) {
    return next();
  }

  return res.status(403).json({ error: { code: 'CSRF', message: 'Invalid CSRF token' } });
}
