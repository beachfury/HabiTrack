// apps/api/src/routes.auth.onboard.ts
import type { Request, Response } from 'express';
import { readOnboardToken } from './onboard/token';
import { updateUserSecret, updateUserKioskPin } from './routes.auth.creds.helpers';
import { q } from './db';
import { logAudit } from './audit';
import { MariaDbSessionStore } from '@habitrack/session-store';
import { parseEnv } from '@habitrack/core-config';

const cfg = parseEnv(process.env);
const store = new MariaDbSessionStore({
  host: String(cfg.HABITRACK_DB_HOST ?? '127.0.0.1'),
  port: Number(cfg.HABITRACK_DB_PORT ?? 3306),
  user: String(cfg.HABITRACK_DB_USER ?? 'habitrack_app'),
  password: String(cfg.HABITRACK_DB_PASSWORD ?? ''),
  database: String(cfg.HABITRACK_DB_NAME ?? 'habitrack'),
  connectionLimit: Number(cfg.HABITRACK_DB_POOL_MAX ?? 10),
  requireTls:
    String(cfg.HABITRACK_ENV || '').toLowerCase() === 'production' &&
    String(cfg.HABITRACK_DB_REQUIRE_TLS ?? 'false')
      .trim()
      .toLowerCase() === 'true',
});

export async function postOnboardComplete(req: Request, res: Response) {
  const { token, newSecret, kioskPin } = (req.body ?? {}) as {
    token?: string;
    newSecret?: string;
    kioskPin?: string;
  };

  if (!token || !newSecret || !kioskPin) {
    return res
      .status(400)
      .json({ error: { code: 'BAD_REQUEST', message: 'token, newSecret, kioskPin required' } });
  }

  const info = readOnboardToken(token);
  if (!info) return res.status(400).json({ error: { code: 'INVALID_TOKEN' } });

  const userId = info.userId;

  // set new password + kiosk pin
  await updateUserSecret(userId, newSecret);
  await updateUserKioskPin(userId, kioskPin);

  // clear first-login flag
  await q('UPDATE users SET firstLoginRequired=0 WHERE id=?', [userId]);

  // rotate sessions just in case
  await q('DELETE FROM sessions WHERE user_id=?', [userId]).catch(() => {});

  // create fresh session and set cookie
  const role = await (async () => {
    const r = await q<Array<{ roleId: 'admin' | 'member' | 'kid' | 'kiosk' }>>(
      'SELECT roleId FROM users WHERE id=? LIMIT 1',
      [userId],
    );
    return r[0]?.roleId ?? 'member';
  })();

  const ttlMinutes = Number(process.env.HABITRACK_SESSION_TTL_MINUTES ?? 120) || 120;
  const sess = await store.create({ userId, role, ttlMinutes });

  // reuse the cookie setter you already have (or duplicate briefly here)
  res.cookie(String(process.env.HABITRACK_SESSION_COOKIE_NAME ?? 'habitrack_sid'), sess.sid, {
    httpOnly: true,
    secure:
      String(process.env.HABITRACK_ENV || process.env.NODE_ENV || 'development').toLowerCase() ===
        'production' &&
      (String(process.env.HABITRACK_COOKIE_SECURE ?? 'true')
        .trim()
        .toLowerCase() === 'true' ||
        String(process.env.HABITRACK_COOKIE_SAMESITE ?? 'Lax').toLowerCase() === 'none'),
    sameSite: String(process.env.HABITRACK_COOKIE_SAMESITE ?? 'Lax').toLowerCase() as any,
    path: '/',
    maxAge: ttlMinutes * 60_000,
  });

  await logAudit({ action: 'auth.onboard.complete', result: 'ok', actorId: userId });

  return res.status(204).end();
}
