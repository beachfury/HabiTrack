// apps/api/src/routes.auth.creds.ts
import type { Request, Response } from 'express';
import crypto from 'node:crypto';
import argon2 from 'argon2';
import { parseEnv } from '@habitrack/core-config';
import { MariaDbSessionStore } from '@habitrack/session-store';
import { q } from './db';
import { logAudit } from './audit';
import { Notifier } from './notify';
import { makeOnboardToken } from './onboard/token';

/* =========================
 *  Argon2 helpers (real)
 * ========================= */
const ARGON2_OPTS: argon2.Options & { raw: true } = {
  type: argon2.argon2id,
  timeCost: 3,
  memoryCost: 64 * 1024, // 64MB
  parallelism: 1,
  raw: true, // store raw bytes in VARBINARY
};
const SALT_BYTES = 16;

function timingSafeEq(a: Buffer, b: Buffer): boolean {
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

async function hashSecret(secret: string): Promise<{ salt: Buffer; hash: Buffer }> {
  const salt = crypto.randomBytes(SALT_BYTES);
  const hash = (await argon2.hash(secret, { ...ARGON2_OPTS, salt })) as Buffer;
  return { salt, hash };
}

async function updateUserSecret(userId: number, secret: string) {
  const { salt, hash } = await hashSecret(secret);
  await q(
    `INSERT INTO credentials (userId, provider, algo, salt, hash, updatedAt)
       VALUES (?, 'password', 'argon2id', ?, ?, NOW(3))
     ON DUPLICATE KEY UPDATE
       algo = VALUES(algo),
       salt = VALUES(salt),
       hash = VALUES(hash),
       updatedAt = VALUES(updatedAt)`,
    [userId, salt, hash],
  );
}

async function verifyUserSecret(userId: number, secret: string): Promise<boolean> {
  const rows = await q<Array<{ algo: string; salt: Buffer; hash: Buffer }>>(
    `SELECT algo, salt, hash
       FROM credentials
      WHERE userId = ? AND provider = 'password'
      LIMIT 1`,
    [userId],
  );
  const row = rows?.[0];
  if (!row || String(row.algo).toLowerCase() !== 'argon2id') return false;
  const calc = (await argon2.hash(secret, { ...ARGON2_OPTS, salt: row.salt })) as Buffer;
  return timingSafeEq(calc, row.hash);
}

/* =========================
 *  Config / session setup
 * ========================= */
const cfg = parseEnv(process.env);

const IS_DEV =
  String(cfg.HABITRACK_ENV || process.env.NODE_ENV || 'development').toLowerCase() !== 'production';

const COOKIE_NAME = String(cfg.HABITRACK_SESSION_COOKIE_NAME ?? 'habitrack_sid');
const COOKIE_SAMESITE_STR = String(cfg.HABITRACK_COOKIE_SAMESITE ?? 'Lax');
const COOKIE_SAMESITE = COOKIE_SAMESITE_STR.trim().toLowerCase() as 'lax' | 'strict' | 'none';

// In dev, force secure=false. In prod, require env true or SameSite=None.
const COOKIE_SECURE =
  !IS_DEV &&
  (String(cfg.HABITRACK_COOKIE_SECURE ?? 'true')
    .trim()
    .toLowerCase() === 'true' ||
    COOKIE_SAMESITE === 'none');

const SESSION_TTL_MIN = Number(cfg.HABITRACK_SESSION_TTL_MINUTES ?? 120) || 120;

const REQUIRE_TLS =
  String(cfg.HABITRACK_ENV || '').toLowerCase() === 'production' &&
  String(cfg.HABITRACK_DB_REQUIRE_TLS ?? 'false')
    .trim()
    .toLowerCase() === 'true';

const store = new MariaDbSessionStore({
  host: String(cfg.HABITRACK_DB_HOST ?? '127.0.0.1'),
  port: Number(cfg.HABITRACK_DB_PORT ?? 3306),
  user: String(cfg.HABITRACK_DB_USER ?? 'habitrack_app'),
  password: String(cfg.HABITRACK_DB_PASSWORD ?? ''),
  database: String(cfg.HABITRACK_DB_NAME ?? 'habitrack'),
  connectionLimit: Number(cfg.HABITRACK_DB_POOL_MAX ?? 10),
  requireTls: REQUIRE_TLS,
});

function setSessionCookie(res: Response, sid: string) {
  res.cookie(COOKIE_NAME, sid, {
    httpOnly: true,
    secure: COOKIE_SECURE, // false in dev
    sameSite: COOKIE_SAMESITE,
    path: '/',
    maxAge: SESSION_TTL_MIN * 60_000,
  });
}

console.log('[auth.creds] cookie', {
  name: COOKIE_NAME,
  secure: COOKIE_SECURE,
  sameSite: COOKIE_SAMESITE,
  ttlMin: SESSION_TTL_MIN,
  env: IS_DEV ? 'dev' : 'prod',
});

/* =========================
 *  Helpers
 * ========================= */
function clientMeta(req: Request) {
  return {
    ip:
      (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() ||
      (req.socket?.remoteAddress ?? undefined),
    ua: (req.headers['user-agent'] as string | undefined) ?? undefined,
  };
}

async function getUserRole(userId: number): Promise<'admin' | 'member' | 'kid' | 'kiosk'> {
  const rows = await q<Array<{ roleId: 'admin' | 'member' | 'kid' | 'kiosk' }>>(
    'SELECT roleId FROM users WHERE id = ? LIMIT 1',
    [userId],
  );
  return rows[0]?.roleId ?? 'member';
}

/* =========================
 *  Routes
 * ========================= */

// === POST /api/auth/creds/register =========================================
// Registers/updates the secret for an existing user and creates a session.
export async function postRegisterCreds(req: Request, res: Response) {
  const { userId, secret } = (req.body ?? {}) as { userId?: number; secret?: string };
  if (!userId || !secret) {
    return res
      .status(400)
      .json({ error: { code: 'BAD_REQUEST', message: 'userId and secret required' } });
  }

  const u = await q<Array<{ id: number }>>('SELECT id FROM users WHERE id=? LIMIT 1', [userId]);
  if (!u.length) {
    return res.status(404).json({ error: { code: 'USER_NOT_FOUND' } });
  }

  await updateUserSecret(userId, secret);

  await logAudit({
    action: 'auth.register',
    result: 'ok',
    ...clientMeta(req),
    details: { userId },
  });

  const role = await getUserRole(userId);
  const sess = await store.create({ userId, role, ttlMinutes: SESSION_TTL_MIN });
  setSessionCookie(res, sess.sid);
  return res.status(204).end();
}

// === POST /api/auth/creds/reset ============================================
// Body: { userId, code, newSecret }
// Verifies the reset code, sets the new password, rotates sessions, logs the user in.
export async function postResetPassword(req: Request, res: Response) {
  const { userId, code, newSecret } = (req.body ?? {}) as {
    userId?: number;
    code?: string;
    newSecret?: string;
  };
  const { ip, ua } = clientMeta(req);

  try {
    if (!userId || !code || !newSecret) {
      return res.status(400).json({
        error: { code: 'BAD_REQUEST', message: 'userId, code and newSecret required' },
      });
    }

    // Must match non-expired row with the given user+code
    const rows = await q<Array<{ attempts: number }>>(
      `SELECT attempts
         FROM password_resets
        WHERE userId = ?
          AND codeHash = UNHEX(SHA2(?,256))
          AND expiresAt > NOW(3)
        ORDER BY createdAt DESC
        LIMIT 1`,
      [userId, code],
    );

    if (!rows.length) {
      // Optional: bump attempts on the most recent row for this user
      await q(
        `UPDATE password_resets
            SET attempts = LEAST(attempts + 1, 255)
          WHERE userId = ?
          ORDER BY createdAt DESC
          LIMIT 1`,
        [userId],
      ).catch(() => {});
      await logAudit({
        action: 'auth.reset',
        result: 'deny',
        actorId: userId,
        ip,
        ua,
        details: { reason: 'INVALID_OR_EXPIRED_CODE' },
      });
      return res.status(400).json({ error: { code: 'INVALID_OR_EXPIRED_CODE' } });
    }

    // Set the new password (argon2id into credentials table)
    await updateUserSecret(userId, newSecret);

    // Invalidate all existing sessions for this user
    await q('DELETE FROM sessions WHERE user_id = ?', [userId]).catch(() => {});

    // Issue a fresh session so they’re logged in immediately
    const role = await getUserRole(userId);
    const sess = await store.create({ userId, role, ttlMinutes: SESSION_TTL_MIN });
    setSessionCookie(res, sess.sid);

    await logAudit({ action: 'auth.reset', result: 'ok', actorId: userId, ip, ua });
    return res.status(204).end();
  } catch (err) {
    console.error('[postResetPassword] error', err);
    await logAudit({
      action: 'auth.reset',
      result: 'error',
      actorId: userId,
      ip,
      ua,
      details: { error: String(err) },
    });
    return res.status(500).json({ error: { code: 'SERVER_ERROR' } });
  }
}

// === POST /api/auth/creds/login ============================================
// Validates secret and creates a new session.
export async function postLoginCreds(req: Request, res: Response) {
  const { userId, secret } = (req.body ?? {}) as { userId?: number; secret?: string };
  if (!userId || !secret) {
    return res
      .status(400)
      .json({ error: { code: 'BAD_REQUEST', message: 'userId and secret required' } });
  }

  try {
    const ok = await verifyUserSecret(userId, secret);
    if (!ok) {
      await logAudit({
        action: 'auth.login.fail',
        result: 'error',
        ...clientMeta(req),
        details: { userId },
      });

      // If you later wire lockouts, replace the stub:
      const locked = await isLocked(userId);
      if (locked) {
        await logAudit({
          action: 'auth.lockout',
          result: 'error',
          ...clientMeta(req),
          details: { userId },
        });
        return res.status(423).json({ error: { code: 'ACCOUNT_LOCKED' } });
      }

      return res.status(401).json({ error: { code: 'BAD_CREDENTIALS' } });
    }
  } catch (e) {
    if ((e as any)?.code === 'ACCOUNT_LOCKED') {
      await logAudit({
        action: 'auth.lockout',
        result: 'error',
        ...clientMeta(req),
        details: { userId },
      });
      return res.status(423).json({ error: { code: 'ACCOUNT_LOCKED' } });
    }
    throw e;
  }

  const role = await getUserRole(userId);
  const sess = await store.create({ userId, role, ttlMinutes: SESSION_TTL_MIN });
  setSessionCookie(res, sess.sid);

  await logAudit({
    action: 'auth.login.ok',
    result: 'ok',
    ...clientMeta(req),
    details: { userId, sid: sess.sid },
  });

  // inside postLoginCreds, after secret verified:
  const u = await q<Array<{ firstLoginRequired: number }>>(
    'SELECT firstLoginRequired FROM users WHERE id=? LIMIT 1',
    [userId],
  );
  if (u[0]?.firstLoginRequired) {
    const exp = Date.now() + 10 * 60_000;
    const token = makeOnboardToken(userId, 'onboard', exp);
    // 428 Precondition Required: client must complete onboarding
    return res.status(428).json({ error: { code: 'FIRST_LOGIN_REQUIRED' }, onboardToken: token });
  }

  // else: proceed exactly as today (create session + cookie, 204)

  return res.status(204).end();
}

// === POST /api/auth/creds/forgot ===========================================
// Dev: returns { ok:true, devCode:"000000" }. Persists hash into password_resets.
export async function postForgotPassword(req: Request, res: Response) {
  const { userId } = (req.body ?? {}) as { userId?: number };
  const { ip, ua } = clientMeta(req);

  try {
    if (!userId) {
      return res.status(400).json({ error: { code: 'BAD_REQUEST', message: 'userId required' } });
    }

    const devCode = '000000';

    // Persist reset row (expires in 10 minutes); if it fails, we still proceed in dev.
    try {
      await q(
        `INSERT INTO password_resets (userId, codeHash, expiresAt, attempts, createdAt)
           VALUES (?, UNHEX(SHA2(?,256)), NOW(3) + INTERVAL 10 MINUTE, 0, NOW(3))
         ON DUPLICATE KEY UPDATE
           codeHash  = VALUES(codeHash),
           expiresAt = VALUES(expiresAt),
           attempts  = 0,
           createdAt = VALUES(createdAt)`,
        [userId, devCode],
      );
    } catch (sqlErr) {
      console.error('[auth.forgot] insert error (dev continues):', sqlErr);
    }

    // Optional: fire-and-forget notification (no-op for now)
    Notifier.enqueue({
      kind: 'password_reset_code',
      userId,
      toEmail: process.env.SMTP_TEST_TO || 'your.address@example.com', // or null if you prefer
      subject: 'Your HabiTrack reset code',
      text: `Your code is ${devCode}. It expires in 10 minutes.`,
      html: `<p>Your code is <b>${devCode}</b>. It expires in 10 minutes.</p>`,
    }).catch((err) => {
      // never let email failures bubble up into the request
      console.error('[notify.enqueue] non-fatal:', err);
    });

    await logAudit({ action: 'auth.forgot', result: 'ok', actorId: userId, ip, ua });
    return res.json({ ok: true, devCode });
  } catch (err) {
    console.error('[postForgotPassword] error', err);
    await logAudit({
      action: 'auth.forgot',
      result: 'error',
      actorId: userId,
      ip,
      ua,
      details: { error: String(err) },
    });
    return res.status(500).json({ error: { code: 'SERVER_ERROR' } });
  }
}

// === POST /api/auth/creds/change ===========================================
// Requires an existing cookie session + CSRF (route is registered after csrfProtect).
export async function postChangePassword(req: Request, res: Response) {
  const { oldSecret, newSecret } = (req.body ?? {}) as { oldSecret?: string; newSecret?: string };
  if (!oldSecret || !newSecret) {
    return res
      .status(400)
      .json({ error: { code: 'BAD_REQUEST', message: 'oldSecret and newSecret required' } });
  }

  // Identify user from current session cookie
  const sid = (req.cookies?.[COOKIE_NAME] ?? '').trim();
  if (!sid) return res.status(401).json({ error: { code: 'AUTH_REQUIRED' } });

  const sess = await store.get(sid);
  if (!sess) return res.status(401).json({ error: { code: 'AUTH_EXPIRED' } });

  const userId = sess.userId;

  // Verify old password
  const okOld = await verifyUserSecret(userId, oldSecret);
  if (!okOld) {
    await logAudit({
      action: 'auth.password.change',
      result: 'deny',
      ...clientMeta(req),
      details: { userId, reason: 'old_secret_mismatch' },
    });
    return res.status(401).json({ error: { code: 'BAD_CREDENTIALS' } });
  }

  // Update to new password
  await updateUserSecret(userId, newSecret);

  // Rotate all sessions for safety
  await q('DELETE FROM sessions WHERE user_id = ?', [userId]);

  // Issue a fresh session
  const role = await getUserRole(userId);
  const newSess = await store.create({ userId, role, ttlMinutes: SESSION_TTL_MIN });
  setSessionCookie(res, newSess.sid);

  await logAudit({
    action: 'auth.password.change',
    result: 'ok',
    ...clientMeta(req),
    details: { userId, rotatedSessions: true, newSid: newSess.sid },
  });

  return res.status(204).end();
}

/* =========================
 *  Stubs you can wire later
 * ========================= */
async function isLocked(_userId: number): Promise<boolean> {
  // Replace with your lockout checker (based on HABITRACK_CRED_* envs).
  return false;
}
