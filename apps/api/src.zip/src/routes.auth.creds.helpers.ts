// apps/api/src/routes.auth.creds.helpers.ts
import crypto from 'node:crypto';
import argon2 from 'argon2';
import { q } from './db';

// === Argon2 config (same as in routes.auth.creds.ts) ===
const ARGON2_OPTS: argon2.Options & { raw: true } = {
  type: argon2.argon2id,
  timeCost: 3,
  memoryCost: 64 * 1024, // 64MB
  parallelism: 1,
  raw: true,
};
const SALT_BYTES = 16;

function timingSafeEq(a: Buffer, b: Buffer): boolean {
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

async function hashSecret(secret: string): Promise<{ salt: Buffer; hash: Buffer }> {
  const salt = crypto.randomBytes(SALT_BYTES);
  const hash = (await argon2.hash(secret, { ...ARGON2_OPTS, salt })) as Buffer;
  return { salt, hash };
}

export async function updateUserSecret(userId: number, secret: string) {
  const { salt, hash } = await hashSecret(secret);
  await q(
    `INSERT INTO credentials (userId, provider, algo, salt, hash, updatedAt)
       VALUES (?, 'password', 'argon2id', ?, ?, NOW(3))
     ON DUPLICATE KEY UPDATE
       algo = VALUES(algo),
       salt = VALUES(salt),
       hash = VALUES(hash),
       updatedAt = VALUES(updatedAt)`,
    [userId, salt, hash],
  );
}

export async function updateUserKioskPin(userId: number, pin: string) {
  const { salt, hash } = await hashSecret(pin);
  await q(
    `INSERT INTO credentials (userId, provider, algo, salt, hash, updatedAt)
       VALUES (?, 'kiosk_pin', 'argon2id', ?, ?, NOW(3))
     ON DUPLICATE KEY UPDATE
       algo = VALUES(algo),
       salt = VALUES(salt),
       hash = VALUES(hash),
       updatedAt = VALUES(updatedAt)`,
    [userId, salt, hash],
  );
}

export async function verifyUserSecret(userId: number, secret: string): Promise<boolean> {
  const rows = await q<Array<{ algo: string; salt: Buffer; hash: Buffer }>>(
    `SELECT algo, salt, hash
       FROM credentials
      WHERE userId = ? AND provider = 'password'
      LIMIT 1`,
    [userId],
  );
  const row = rows?.[0];
  if (!row || String(row.algo).toLowerCase() !== 'argon2id') return false;
  const calc = (await argon2.hash(secret, { ...ARGON2_OPTS, salt: row.salt })) as Buffer;
  return timingSafeEq(calc, row.hash);
}

export async function getUserRole(userId: number): Promise<'admin' | 'member' | 'kid' | 'kiosk'> {
  const rows = await q<Array<{ roleId: 'admin' | 'member' | 'kid' | 'kiosk' }>>(
    'SELECT roleId FROM users WHERE id = ? LIMIT 1',
    [userId],
  );
  return rows[0]?.roleId ?? 'member';
}
