import type { Request, Response, NextFunction } from 'express';
import { parseEnv } from '@habitrack/core-config';
import { MariaDbSessionStore } from '@habitrack/session-store';
import { q } from './db';

const cfg = parseEnv(process.env);

// --- env / flags ---
const IS_DEV =
  String(cfg.HABITRACK_ENV || process.env.NODE_ENV || 'development').toLowerCase() !== 'production';

const COOKIE_NAME = String(cfg.HABITRACK_SESSION_COOKIE_NAME ?? 'habitrack_sid');
const COOKIE_SAMESITE_STR = String(cfg.HABITRACK_COOKIE_SAMESITE ?? 'Lax');
const COOKIE_SAMESITE = COOKIE_SAMESITE_STR.trim().toLowerCase() as 'lax' | 'strict' | 'none';

const COOKIE_SECURE =
  !IS_DEV &&
  (String(cfg.HABITRACK_COOKIE_SECURE ?? 'true')
    .trim()
    .toLowerCase() === 'true' ||
    COOKIE_SAMESITE === 'none');

const SESSION_TTL_MIN = Number(cfg.HABITRACK_SESSION_TTL_MINUTES ?? 120) || 120;
const SESSION_ROLLING = String(cfg.HABITRACK_SESSION_ROLLING ?? 'true').toLowerCase() === 'true';

console.log('[middleware.auth] cookie', {
  name: COOKIE_NAME,
  secure: COOKIE_SECURE,
  sameSite: COOKIE_SAMESITE,
  env: IS_DEV ? 'dev' : 'prod',
});

// Prod-only TLS to DB
const REQUIRE_TLS =
  String(cfg.HABITRACK_ENV || '').toLowerCase() === 'production' &&
  String(cfg.HABITRACK_DB_REQUIRE_TLS ?? 'false')
    .trim()
    .toLowerCase() === 'true';

// --- Session store (mysql2) ---
const store = new MariaDbSessionStore({
  host: String(cfg.HABITRACK_DB_HOST ?? '127.0.0.1'),
  port: Number(cfg.HABITRACK_DB_PORT ?? 3306),
  user: String(cfg.HABITRACK_DB_USER ?? 'habitrack_app'),
  password: String(cfg.HABITRACK_DB_PASSWORD ?? ''),
  database: String(cfg.HABITRACK_DB_NAME ?? 'habitrack'),
  connectionLimit: Number(cfg.HABITRACK_DB_POOL_MAX ?? 10),
  requireTls: REQUIRE_TLS,
});

function setSessionCookie(res: Response, sid: string) {
  res.cookie(COOKIE_NAME, sid, {
    httpOnly: true,
    secure: COOKIE_SECURE, // false in dev, true in prod
    sameSite: COOKIE_SAMESITE, // 'lax' in dev, 'none' in prod if you choose
    path: '/',
    maxAge: SESSION_TTL_MIN * 60_000,
  });
}

// --- Augment Express Request ---
declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface UserInfo {
      id: number;
      displayName: string;
      roleId: 'admin' | 'member' | 'kid' | 'kiosk';
    }
    interface Request {
      user?: UserInfo;
      sessionId?: string;
    }
  }
}

/**
 * requireAuth middleware:
 *  - reads session cookie
 *  - loads session from DB
 *  - (optional) rolls expiration and refreshes cookie
 *  - loads user info and attaches req.user
 */
export function requireAuth(...allowedRoles: Express.UserInfo['roleId'][]) {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const sid = (req.cookies?.[COOKIE_NAME] ?? '').trim();
      if (!sid) {
        return res.status(401).json({ error: { code: 'AUTH_REQUIRED' } });
      }

      const sess = await store.get(sid);
      if (!sess) {
        return res.status(401).json({ error: { code: 'AUTH_EXPIRED' } });
      }

      // Load user from DB
      const rows = await q<Array<{ id: number; displayName: string; roleId: any; active: 0 | 1 }>>(
        'SELECT id, displayName, roleId, active FROM users WHERE id = ? LIMIT 1',
        [sess.userId],
      );
      const u = rows[0];
      if (!u || !u.active) {
        return res.status(403).json({ error: { code: 'USER_INACTIVE' } });
      }

      // Role check
      if (allowedRoles.length && !allowedRoles.includes(u.roleId)) {
        return res.status(403).json({ error: { code: 'FORBIDDEN' } });
      }

      // Rolling session
      if (SESSION_ROLLING) {
        await store.touch(sid, SESSION_TTL_MIN);
        setSessionCookie(res, sid);
      }

      req.sessionId = sid;
      req.user = { id: u.id, displayName: u.displayName, roleId: u.roleId };
      return next();
    } catch (err) {
      console.error('[requireAuth] error', err);
      return res.status(500).json({ error: { code: 'INTERNAL' } });
    }
  };
}
